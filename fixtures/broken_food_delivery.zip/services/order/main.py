import os
import requests
from fastapi import FastAPI, HTTPException

app = FastAPI(title="Order Service")

PAYMENT_URL = os.getenv("PAYMENT_SERVICE_URL", "http://payment-service:8002")

@app.post("/api/orders")
def create_order(order_data: dict):
    # Route mismatch: calls /api/payments but payment service defines /api/payment
    res = requests.post(f"{PAYMENT_URL}/api/payments", json={"amount": order_data.get("amount", 25.0)})
    if res.status_code != 200:
        raise HTTPException(status_code=502, detail="Payment authorization rejected")
    return {"order_id": "ord-9921", "status": "CONFIRMED"}

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "order-service"}
