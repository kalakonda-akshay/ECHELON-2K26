import os

# Issue: missing env fallback causes fatal TypeError when DATABASE_PORT is not set
DATABASE_PORT = int(os.getenv("DATABASE_PORT"))

# Issue: hardcoded localhost instead of Docker Compose service postgres-db
DB_HOST = host="localhost"
