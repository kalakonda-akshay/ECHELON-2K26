from fastapi import FastAPI
from services.payment.config import DATABASE_PORT, DB_HOST

app = FastAPI(title="Payment Service")

@app.post("/api/payment")
def process_payment(payload: dict):
    return {"payment_id": "pay-8821", "status": "AUTHORIZED", "amount": payload.get("amount")}

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "payment-service"}
