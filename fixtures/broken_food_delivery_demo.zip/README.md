# Payment API Microservices (Broken Demo)

## Overview
This is an e-commerce microservices cluster consisting of:
- **Order Service**: Orchestrates orders and initiates payment charges.
- **Payment Service**: Processes credit card authorizations.
- **Postgres Database**: Stores ledger and transaction records.

## Known Blocking Issues (Ready for TraceRoute Project Repair Lab)
1. **API Route Contract Mismatch**: Order Service calls `POST /api/payments`, but Payment Service only exposes `POST /api/payment`.
2. **Missing Environment Variable Fallback**: `DATABASE_PORT = int(os.getenv("DATABASE_PORT"))` causes a fatal startup crash when `DATABASE_PORT` is unset.
3. **Missing Declared Dependency**: Order Service imports `requests` in `main.py` but `requests` is missing from `requirements.txt`.

## How to Test in TraceRoute AI
1. Go to **Connect Project** -> Upload this ZIP or click **Broken Food Delivery / Payment API Demo**.
2. Observe automated discovery detecting all 3 blockers.
3. Open **Project Repair Lab** -> Click **"Make It Work"**.
4. Download the newly generated repaired ZIP and inspect the applied code fixes!
