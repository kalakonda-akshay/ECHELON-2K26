from fastapi import FastAPI, HTTPException
import requests
import os

app = FastAPI(title="Order Service", version="1.0.0")

PAYMENT_SERVICE_URL = os.getenv("PAYMENT_SERVICE_URL", "http://payment-service:8002")

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "order-service"}

@app.post("/api/orders/create")
def create_order(payload: dict):
    # ISSUE: Calls /api/payments (plural) but payment service defines /api/payment (singular)
    resp = requests.post(f"{PAYMENT_SERVICE_URL}/api/payments", json={"amount": payload.get("amount", 99.0)})
    if resp.status_code != 200:
        raise HTTPException(status_code=502, detail="Payment gateway failure")
    return {"order_id": "ord-9921", "payment": resp.json()}
