import os

# ISSUE: Missing env fallback causes fatal TypeError when DATABASE_PORT is not set
DATABASE_PORT = int(os.getenv("DATABASE_PORT"))

DB_HOST = os.getenv("DB_HOST", "postgres-db")
