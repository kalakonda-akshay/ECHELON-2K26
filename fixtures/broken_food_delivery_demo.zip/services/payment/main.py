from fastapi import FastAPI
from services.payment.config import DATABASE_PORT, DB_HOST

app = FastAPI(title="Payment Service", version="1.0.0")

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "payment-service", "port": DATABASE_PORT}

@app.post("/api/payment")
def process_payment(payload: dict):
    return {
        "transaction_id": "tx-8819",
        "status": "AUTHORIZED",
        "amount": payload.get("amount", 0.0)
    }
