# E-Commerce Payment Gateway

## Architecture
- **Order Service** (`:8001`): Cart orchestration and order placement
- **Payment Service** (`:8002`): Credit card processing & gateway tokens
- **PostgreSQL Database** (`:5432`): ACID transactions ledger

## Known Production Blockers (Ready for TraceRoot Repair Lab)
1. **API Route Mismatch**: Order service calls `POST /api/payments`, but Payment service declares `POST /api/payment` (HTTP 404).
2. **Missing Environment Fallback**: `int(os.getenv("DATABASE_PORT"))` crashes with TypeError if `DATABASE_PORT` is unset.
3. **Missing Dependency**: Order service imports `requests` but omits it from `requirements.txt`.
