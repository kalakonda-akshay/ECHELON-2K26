from fastapi import FastAPI, HTTPException
import requests
import os

app = FastAPI(title="Order Service", version="1.0.0")
PAYMENT_SERVICE_URL = os.getenv("PAYMENT_SERVICE_URL", "http://payment-service:8002")

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "order-service"}

@app.post("/api/v1/orders")
def create_order(item_id: str, amount: float):
    # ISSUE: Route mismatch - calls /api/payments instead of /api/payment
    resp = requests.post(f"{PAYMENT_SERVICE_URL}/api/payments", json={"item_id": item_id, "amount": amount})
    if resp.status_code != 200:
        raise HTTPException(status_code=502, detail="Payment authorization failed")
    return {"order_id": "ord_9941", "status": "CONFIRMED"}
