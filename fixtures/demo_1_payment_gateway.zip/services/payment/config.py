import os

# ISSUE: Missing fallback causes TypeError when DATABASE_PORT is not configured
DATABASE_PORT = int(os.getenv("DATABASE_PORT"))
DB_HOST = os.getenv("DB_HOST", "postgres-db")
