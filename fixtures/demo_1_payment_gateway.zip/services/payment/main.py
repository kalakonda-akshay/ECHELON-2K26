from fastapi import FastAPI
from services.payment.config import DATABASE_PORT, DB_HOST

app = FastAPI(title="Payment Service", version="1.0.0")

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "payment-service", "port": DATABASE_PORT}

@app.post("/api/payment")
def process_charge(data: dict):
    return {"status": "SUCCESS", "tx_id": "tx_8812", "amount": data.get("amount", 0)}
