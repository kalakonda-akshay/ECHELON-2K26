# RideShare Dispatch & Fleet Tracking

## Architecture
- **Dispatch Service** (`:8001`): Rider pickup assignment
- **Driver Service** (`:8002`): Live GPS coordinates & driver status
- **Redis Cluster** (`:6379`): Geospatial cache

## Known Production Blockers (Ready for TraceRoot Repair Lab)
1. **Unsafe Environment Key**: Direct `os.environ["REDIS_URL"]` lookup raises unhandled `KeyError` on startup.
2. **Missing Environment Fallback**: `int(os.getenv("DISPATCH_PORT"))` causes crash when port env var is omitted.
3. **API Route Mismatch**: Dispatch calls `POST /api/drivers` while Driver service exposes `POST /api/driver`.
4. **Missing Health Probe**: Driver service lacks `/health` endpoint required for Kubernetes/Docker liveness.
