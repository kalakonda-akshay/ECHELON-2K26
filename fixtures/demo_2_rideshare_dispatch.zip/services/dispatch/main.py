from fastapi import FastAPI, HTTPException
import requests
import os

app = FastAPI(title="Dispatch Service", version="1.0.0")
DRIVER_SERVICE_URL = os.getenv("DRIVER_SERVICE_URL", "http://driver-service:8002")

# ISSUE: Missing fallback on integer port conversion
DISPATCH_PORT = int(os.getenv("DISPATCH_PORT"))

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "dispatch-service"}

@app.post("/api/v1/dispatch")
def dispatch_ride(rider_id: str, lat: float, lng: float):
    # ISSUE: Route mismatch - calls /api/drivers instead of declared /api/driver
    resp = requests.post(f"{DRIVER_SERVICE_URL}/api/drivers", json={"rider_id": rider_id, "lat": lat, "lng": lng})
    if resp.status_code != 200:
        raise HTTPException(status_code=503, detail="No driver available")
    return {"dispatch_id": "disp_441", "status": "ASSIGNED"}
