from fastapi import FastAPI
import os

app = FastAPI(title="Driver Service", version="1.0.0")

# ISSUE: Direct os.environ indexing raises KeyError if REDIS_URL is not set
REDIS_URL = os.environ["REDIS_URL"]

@app.post("/api/driver")
def locate_driver(payload: dict):
    return {"driver_id": "drv_771", "status": "EN_ROUTE", "eta_minutes": 4}
