# Food Delivery Kitchen & Order Management

## Architecture
- **Order Service** (`:8001`): Customer cart & payment dispatch
- **Kitchen Service** (`:8002`): Restaurant preparation queue & tickets
- **Postgres Database** (`:5432`): Menu & order records

## Known Production Blockers (Ready for TraceRoot Repair Lab)
1. **Python Syntax Error**: Missing colon `:` on endpoint declaration in `kitchen/main.py`.
2. **Missing Environment Fallback**: `int(os.getenv("DB_PORT"))` crashes if DB_PORT is not passed.
3. **Missing Dependency**: Order service imports `requests` but does not list it in `requirements.txt`.
4. **API Route Mismatch**: Order service calls `POST /api/kitchens` while Kitchen service exposes `POST /api/kitchen`.
