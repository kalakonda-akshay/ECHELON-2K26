from fastapi import FastAPI
import os

app = FastAPI(title="Kitchen Service", version="1.0.0")

# ISSUE: Missing fallback causes TypeError
DB_PORT = int(os.getenv("DB_PORT"))

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "kitchen-service"}

# ISSUE: Fatal SyntaxError - missing colon at end of function declaration
@app.post("/api/kitchen")
def accept_ticket(ticket: dict)
    return {"status": "ACCEPTED", "estimated_mins": 25}
