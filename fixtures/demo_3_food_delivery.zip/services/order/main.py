from fastapi import FastAPI, HTTPException
import requests
import os

app = FastAPI(title="Food Order Service", version="1.0.0")
KITCHEN_SERVICE_URL = os.getenv("KITCHEN_SERVICE_URL", "http://kitchen-service:8002")

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "food-order-service"}

@app.post("/api/v1/orders/place")
def place_order(restaurant_id: str, items: list):
    # ISSUE: Route mismatch - calls /api/kitchens instead of /api/kitchen
    resp = requests.post(f"{KITCHEN_SERVICE_URL}/api/kitchens", json={"restaurant_id": restaurant_id, "items": items})
    if resp.status_code != 200:
        raise HTTPException(status_code=502, detail="Kitchen unreachable")
    return {"order_id": "fd_1002", "status": "PREPARING"}
