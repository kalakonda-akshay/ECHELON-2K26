# Healthcare EHR & Patient Records

## Architecture
- **Appointment Service** (`:8001`): Patient consultation scheduling
- **Patient Service** (`:8002`): Medical charts & demographics storage
- **PostgreSQL Database** (`:5432`): HIPAA encrypted records

## Known Production Blockers (Ready for TraceRoot Repair Lab)
1. **Unsafe Environment Key**: Direct `os.environ["AUTH_SECRET"]` causes crash if key is unset.
2. **Missing Environment Fallback**: `int(os.getenv("POSTGRES_PORT"))` causes crash when port omitted.
3. **API Route Mismatch**: Appointment service calls `POST /api/patients` while Patient service exposes `POST /api/patient`.
4. **Missing Health Probe**: Patient service has no `/health` endpoint for readiness checking.
5. **Missing Dependency**: Appointment service imports `requests` but does not include it in `requirements.txt`.
