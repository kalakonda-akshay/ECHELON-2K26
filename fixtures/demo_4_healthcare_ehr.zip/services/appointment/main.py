from fastapi import FastAPI, HTTPException
import requests
import os

app = FastAPI(title="Appointment Service", version="1.0.0")
PATIENT_SERVICE_URL = os.getenv("PATIENT_SERVICE_URL", "http://patient-service:8002")

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "appointment-service"}

@app.post("/api/v1/appointments")
def schedule_appointment(patient_id: str, doctor_id: str):
    # ISSUE: Route mismatch - calls /api/patients instead of /api/patient
    resp = requests.post(f"{PATIENT_SERVICE_URL}/api/patients", json={"patient_id": patient_id, "doctor": doctor_id})
    if resp.status_code != 200:
        raise HTTPException(status_code=502, detail="Patient lookup failed")
    return {"appointment_id": "apt_7721", "status": "CONFIRMED"}
