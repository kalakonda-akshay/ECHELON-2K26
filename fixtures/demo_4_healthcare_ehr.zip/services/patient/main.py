from fastapi import FastAPI
import os

app = FastAPI(title="Patient Records Service", version="1.0.0")

# ISSUE 1: Direct indexing causes KeyError
AUTH_SECRET = os.environ["AUTH_SECRET"]

# ISSUE 2: Missing fallback causes TypeError
POSTGRES_PORT = int(os.getenv("POSTGRES_PORT"))

# ISSUE 3: Missing /health endpoint for container probes

@app.post("/api/patient")
def get_or_create_patient(data: dict):
    return {"patient_id": data.get("patient_id", "pt_unknown"), "status": "ACTIVE"}
