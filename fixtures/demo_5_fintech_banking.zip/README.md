# FinTech Banking Ledger & Wire Transfers

## Architecture
- **Transfer Service** (`:8001`): Outgoing SWIFT & wire orchestration
- **Ledger Service** (`:8002`): Double-entry bookkeeping & balance verification
- **Kafka Cluster** (`:9092`): Audit trail event streaming

## Known Production Blockers (Ready for TraceRoot Repair Lab)
1. **Missing Environment Fallback**: `int(os.getenv("LEDGER_PORT"))` causes crash when port is unset.
2. **Unsafe Environment Key**: Direct `os.environ["KAFKA_BROKER"]` raises `KeyError` on boot.
3. **API Route Mismatch**: Transfer service calls `POST /api/transfers` while Ledger service exposes `POST /api/transfer`.
4. **Missing Dependency**: Transfer service imports `requests` but omits it from `requirements.txt`.
5. **Missing Health Probe**: Ledger service has no `/health` liveness endpoint.
