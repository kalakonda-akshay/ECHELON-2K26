from fastapi import FastAPI
import os

app = FastAPI(title="Ledger Service", version="1.0.0")

# ISSUE 1: Direct indexing causes KeyError
KAFKA_BROKER = os.environ["KAFKA_BROKER"]

# ISSUE 2: Missing /health endpoint

@app.post("/api/transfer")
def record_entry(data: dict):
    return {"entry_id": "entry_331", "status": "COMMITTED", "amount": data.get("amount", 0)}
