from fastapi import FastAPI, HTTPException
import requests
import os

app = FastAPI(title="Transfer Service", version="1.0.0")
LEDGER_SERVICE_URL = os.getenv("LEDGER_SERVICE_URL", "http://ledger-service:8002")

# ISSUE 1: Missing fallback causes TypeError
LEDGER_PORT = int(os.getenv("LEDGER_PORT"))

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "transfer-service"}

@app.post("/api/v1/wires/send")
def send_wire(from_acct: str, to_acct: str, amount: float):
    # ISSUE 2: Route mismatch - calls /api/transfers instead of declared /api/transfer
    resp = requests.post(f"{LEDGER_SERVICE_URL}/api/transfers", json={"from": from_acct, "to": to_acct, "amount": amount})
    if resp.status_code != 200:
        raise HTTPException(status_code=502, detail="Ledger settlement failed")
    return {"wire_id": "wire_9921", "status": "EXECUTED"}
