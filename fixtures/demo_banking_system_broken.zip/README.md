# Banking Transaction Microservices (Broken Demo)

## Services
- **Account Service**: Balance management
- **Transaction Service**: Debit/credit processing
- **Audit Service**: Compliance logging
- **Kafka**: Event streaming

## Known Bugs (for TraceRoot AI Repair Lab)
1. Double-spend vulnerability: Balance check and deduct not atomic (no DB transaction)
2. Missing idempotency key: Retried payments can deduct twice
3. Audit service skipped on error: Transactions fail silently without audit trail
4. Wrong Kafka topic name: 'transactions' vs 'bank-transactions' — events dropped
