from fastapi import FastAPI, HTTPException
import os

app = FastAPI(title="Account Service")

@app.post("/accounts/{account_id}/deduct")
def deduct_balance(account_id: str, amount: float, db=None):
    # BUG: Check and deduct are NOT atomic — race condition / double-spend
    balance = db.execute(
        f"SELECT balance FROM accounts WHERE id='{account_id}'"
    ).fetchone()["balance"]
    
    if balance < amount:
        raise HTTPException(400, "Insufficient funds")
    
    # Another request can deduct between the check above and update below!
    db.execute(
        f"UPDATE accounts SET balance = balance - {amount} WHERE id='{account_id}'"
    )
    db.commit()
    return {"account_id": account_id, "deducted": amount, "new_balance": balance - amount}

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "account-service"}
