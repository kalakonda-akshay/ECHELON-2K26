from fastapi import FastAPI
from kafka import KafkaConsumer
import os, threading

app = FastAPI(title="Audit Service")
# Listens on 'bank-transactions' but publisher sends to 'transactions' — events lost!
KAFKA_TOPIC = os.getenv("KAFKA_TOPIC", "bank-transactions")

def consume_events():
    consumer = KafkaConsumer(
        KAFKA_TOPIC,
        bootstrap_servers=os.getenv("KAFKA_BROKER", "kafka:9092")
    )
    for msg in consumer:
        print(f"AUDIT LOG: {msg.value}")  # BUG: No persistent storage, just stdout

threading.Thread(target=consume_events, daemon=True).start()

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "audit-service", "topic": KAFKA_TOPIC}
