from fastapi import FastAPI, HTTPException
import requests, os
from kafka import KafkaProducer
import json

app = FastAPI(title="Transaction Service")
ACCOUNT_URL = os.getenv("ACCOUNT_SERVICE_URL", "http://account-service:8001")
AUDIT_URL = os.getenv("AUDIT_SERVICE_URL", "http://audit-service:8003")
# BUG: Wrong topic — audit service never receives events
KAFKA_TOPIC = os.getenv("KAFKA_TOPIC", "transactions")

producer = KafkaProducer(
    bootstrap_servers=os.getenv("KAFKA_BROKER", "kafka:9092"),
    value_serializer=lambda v: json.dumps(v).encode()
)

@app.post("/transactions/transfer")
def transfer(from_account: str, to_account: str, amount: float, request_id: str = None):
    # BUG: No idempotency key check — duplicate calls deduct twice
    resp = requests.post(f"{ACCOUNT_URL}/accounts/{from_account}/deduct", 
                         json={"amount": amount})
    if resp.status_code != 200:
        # BUG: Audit event not sent on failure — no audit trail for failed txns
        raise HTTPException(503, "Deduction failed")
    
    # BUG: Publishes to wrong topic 'transactions' not 'bank-transactions'
    producer.send(KAFKA_TOPIC, {"from": from_account, "to": to_account, "amount": amount})
    return {"transaction_id": "txn_001", "status": "COMPLETED"}

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "transaction-service"}
