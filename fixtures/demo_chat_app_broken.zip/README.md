# Real-Time Chat Application (Broken Demo)

## Services  
- **Chat Service**: WebSocket message handling
- **Presence Service**: Online/offline user status
- **Message Store**: MongoDB for message history
- **Redis**: Pub/Sub for real-time delivery

## Known Bugs (for TraceRoot AI Repair Lab)
1. Memory leak: WebSocket connections never removed from registry on disconnect
2. Race condition: Two users joining same room simultaneously causes duplicate messages
3. No message deduplication: Retry logic sends same message multiple times
4. Missing Redis TTL: Presence keys never expire — stale data builds up forever
