from fastapi import FastAPI, WebSocket, WebSocketDisconnect
import asyncio, redis.asyncio as aioredis, os

app = FastAPI(title="Chat Service")

# BUG: Memory leak — connections dict grows forever, never cleaned up
active_connections: dict = {}

@app.websocket("/ws/{room_id}/{user_id}")
async def websocket_endpoint(ws: WebSocket, room_id: str, user_id: str):
    await ws.accept()
    
    # BUG: Race condition — no lock when checking+setting room membership
    if room_id not in active_connections:
        active_connections[room_id] = {}
    active_connections[room_id][user_id] = ws  # Two users can overwrite each other
    
    try:
        while True:
            data = await ws.receive_text()
            # BUG: No deduplication — client retries cause duplicate messages
            for uid, conn in active_connections[room_id].items():
                await conn.send_text(f"{user_id}: {data}")
    except WebSocketDisconnect:
        # BUG: Should remove from active_connections but doesn't
        pass  # Memory leak — ws object stays in dict forever

@app.get("/health")
def health():
    return {"status": "HEALTHY", "active_rooms": len(active_connections)}
