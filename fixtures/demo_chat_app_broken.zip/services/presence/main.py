from fastapi import FastAPI
import redis, os

app = FastAPI(title="Presence Service")
r = redis.Redis.from_url(os.getenv("REDIS_URL", "redis://redis:6379"))
# BUG: TTL=0 means keys never expire — Redis memory grows unbounded
TTL = int(os.getenv("PRESENCE_TTL_SECONDS", "0"))

@app.post("/presence/{user_id}/online")
def set_online(user_id: str):
    if TTL > 0:
        r.setex(f"presence:{user_id}", TTL, "online")
    else:
        # BUG: No expiry — stale presence data stays forever
        r.set(f"presence:{user_id}", "online")
    return {"user_id": user_id, "status": "online"}

@app.get("/presence/{user_id}")
def get_presence(user_id: str):
    status = r.get(f"presence:{user_id}")
    return {"user_id": user_id, "status": status.decode() if status else "offline"}

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "presence-service"}
