# E-Commerce Checkout Microservices (Broken Demo)

## Services
- **Cart Service** (Node.js): Manages shopping cart
- **Inventory Service** (Python): Checks stock availability
- **Checkout Service** (Python): Processes final purchase
- **Postgres DB**: Orders and inventory

## Known Bugs (for TraceRoot AI Repair Lab)
1. HikariCP connection pool exhausted: maximumPoolSize=2 (should be 20)
2. No circuit breaker: Inventory failures cascade to checkout (100% error rate)
3. Deadlock risk: Checkout and Inventory update same rows without consistent lock order
4. Missing timeout: Checkout waits forever if inventory hangs
