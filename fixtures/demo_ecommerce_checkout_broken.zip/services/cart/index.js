const express = require('express');
const axios = require('axios');
const app = express();
app.use(express.json());

const INVENTORY_URL = process.env.INVENTORY_URL || 'http://inventory-service:8001';
const CHECKOUT_URL = process.env.CHECKOUT_URL || 'http://checkout-service:8002';

app.get('/health', (req, res) => res.json({ status: 'HEALTHY', service: 'cart-service' }));

app.post('/cart/checkout', async (req, res) => {
  const { user_id, items } = req.body;
  try {
    // BUG: No timeout set — hangs forever if inventory is slow
    const inv = await axios.post(`${INVENTORY_URL}/inventory/check`, { items });
    if (!inv.data.available) return res.status(409).json({ error: 'Out of stock' });
    const order = await axios.post(`${CHECKOUT_URL}/checkout`, { user_id, items });
    res.json(order.data);
  } catch (err) {
    // BUG: No circuit breaker — every request hits the broken service
    res.status(503).json({ error: 'Checkout failed', detail: err.message });
  }
});

app.listen(3001, () => console.log('Cart service on port 3001'));
