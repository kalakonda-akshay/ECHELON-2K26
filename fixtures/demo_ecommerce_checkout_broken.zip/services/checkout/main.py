from fastapi import FastAPI, HTTPException
import os, requests

app = FastAPI(title="Checkout Service")
INVENTORY_URL = os.getenv("INVENTORY_URL", "http://inventory-service:8001")

@app.post("/checkout")
def process_checkout(user_id: str, items: list):
    # BUG: No timeout — waits forever if inventory is down
    resp = requests.post(f"{INVENTORY_URL}/inventory/reserve", json={"items": items})
    if resp.status_code != 200:
        raise HTTPException(503, "Cannot reserve inventory")
    return {"order_id": "ord_123", "status": "CONFIRMED", "user_id": user_id}

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "checkout-service"}
