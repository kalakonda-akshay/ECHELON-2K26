from fastapi import FastAPI
from sqlalchemy import create_engine
import os

app = FastAPI(title="Inventory Service")

# BUG: pool_size=2 causes HikariCP-style exhaustion under load
engine = create_engine(
    os.getenv("DB_URL"),
    pool_size=int(os.getenv("DB_POOL_SIZE", "2")),
    max_overflow=int(os.getenv("DB_MAX_OVERFLOW", "0"))
)

@app.post("/inventory/check")
def check_stock(items: list):
    with engine.connect() as conn:
        for item in items:
            # BUG: Acquires lock but no consistent order — deadlock risk
            conn.execute(f"SELECT * FROM inventory WHERE sku='{item['sku']}' FOR UPDATE")
    return {"available": True}

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "inventory-service"}
