# Hospital Patient Management System (Broken Demo)

## Services
- **Patient Service**: Patient records CRUD
- **Appointment Service**: Schedules appointments
- **Auth Service**: JWT authentication
- **Postgres DB**: Patient data

## Known Bugs (for TraceRoot AI Repair Lab)
1. SQL Injection: Patient search uses raw string interpolation (no parameterized query)
2. Auth bypass: JWT secret is hardcoded 'secret123' and never verified in middleware  
3. Missing rate limiting: Login endpoint allows brute-force attacks
4. Sensitive data exposure: Patient SSN returned in API response unmasked
