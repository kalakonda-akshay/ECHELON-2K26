from fastapi import FastAPI
import requests, os

app = FastAPI(title="Appointment Service")
PATIENT_URL = os.getenv("PATIENT_SERVICE_URL", "http://patient-service:8002")

@app.post("/appointments")
def create_appointment(patient_id: str, doctor: str, date: str):
    # BUG: Calls patient service without auth token — will fail once auth fixed
    patient = requests.get(f"{PATIENT_URL}/patients/{patient_id}")
    if patient.status_code != 200:
        return {"error": "Patient not found"}
    return {"appointment_id": "apt_001", "patient_id": patient_id, "doctor": doctor, "date": date}

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "appointment-service"}
