from fastapi import FastAPI
import jwt, os

app = FastAPI(title="Auth Service")
# BUG: Hardcoded secret — trivially brute-forceable
JWT_SECRET = os.getenv("JWT_SECRET", "secret123")

@app.post("/auth/login")
# BUG: No rate limiting — allows unlimited brute-force attempts
def login(username: str, password: str):
    # Simplified: no real password check
    token = jwt.encode({"sub": username, "role": "admin"}, JWT_SECRET, algorithm="HS256")
    return {"access_token": token}

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "auth-service"}
