from fastapi import FastAPI, Request
import os

app = FastAPI(title="Patient Service")

@app.get("/patients/search")
def search_patients(name: str, db=None):
    # BUG: SQL INJECTION — raw string interpolation, never use in production
    query = f"SELECT * FROM patients WHERE name LIKE '%{name}%'"
    results = db.execute(query).fetchall()
    # BUG: Returns full SSN unmasked — PII exposure
    return {"patients": [dict(r) for r in results]}

@app.get("/patients/{patient_id}")
def get_patient(patient_id: str, db=None):
    # BUG: No auth check — any caller can fetch any patient record
    patient = db.execute(f"SELECT * FROM patients WHERE id='{patient_id}'").fetchone()
    return dict(patient)  # Returns SSN, DOB, address — no masking

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "patient-service"}
