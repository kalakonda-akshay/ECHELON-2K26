# RideShare Microservices (Broken Demo)

## Services
- **Driver Service**: Tracks driver location and availability
- **Booking Service**: Creates and manages ride bookings
- **Notification Service**: Sends SMS/push alerts
- **Redis Cache**: Driver location cache

## Known Bugs (for TraceRoot AI Repair Lab)
1. OOMKilled: Driver service loads ALL driver records into memory (no pagination)
2. Missing env var: REDIS_URL not set — crashes on startup
3. Wrong HTTP method: Booking calls GET /drivers/assign but service expects POST
4. N+1 query: Notification service runs 1 DB query per user instead of batch
