from fastapi import FastAPI, HTTPException
import requests, os

app = FastAPI(title="Booking Service")
DRIVER_URL = os.getenv("DRIVER_SERVICE_URL", "http://driver-service:8001")

@app.post("/bookings")
def create_booking(user_id: str, pickup: str, dropoff: str):
    # BUG: Calls GET /drivers/assign but driver service requires POST
    resp = requests.get(f"{DRIVER_URL}/drivers/assign",
                        params={"booking_id": "new", "driver_id": "auto"})
    if resp.status_code != 200:
        raise HTTPException(status_code=503, detail="Driver assignment failed")
    return {"booking_id": "bk_001", "status": "CONFIRMED"}

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "booking-service"}
