from fastapi import FastAPI
import os, redis

app = FastAPI(title="Driver Service")

# BUG 1: REDIS_URL has no fallback — crashes with KeyError at startup
redis_client = redis.Redis.from_url(os.environ["REDIS_URL"])

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "driver-service"}

@app.get("/drivers/available")
def get_available_drivers(db=None):
    # BUG 2: Loads ALL 500k drivers into memory — causes OOMKilled
    all_drivers = db.query("SELECT * FROM drivers").fetchall()
    available = [d for d in all_drivers if d["status"] == "available"]
    return {"drivers": available}

@app.get("/drivers/assign")
# BUG 3: Should be POST but registered as GET
def assign_driver(driver_id: str, booking_id: str):
    return {"assigned": True, "driver_id": driver_id, "booking_id": booking_id}
