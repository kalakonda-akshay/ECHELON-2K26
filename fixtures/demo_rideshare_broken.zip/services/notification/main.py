from fastapi import FastAPI
import os

app = FastAPI(title="Notification Service")

@app.post("/notify/bulk")
def send_bulk(user_ids: list, message: str, db=None):
    # BUG: N+1 query — 1 DB hit per user instead of 1 batch query
    results = []
    for uid in user_ids:
        user = db.query(f"SELECT * FROM users WHERE id='{uid}'").fetchone()
        results.append({"user": uid, "sent": True, "email": user["email"]})
    return {"sent": len(results)}

@app.get("/health")
def health():
    return {"status": "HEALTHY", "service": "notification-service"}
