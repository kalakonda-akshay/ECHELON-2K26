# Database Connection Pool Microservices (Broken Demo)

## Overview
Microservices cluster with unhandled database pool constraints:
- Missing `/health` liveness probe on API Gateway.
- Missing HikariCP connection pool timeout defaults in `db_config.py`.
- Missing `psycopg2-binary` declared dependency in `requirements.txt`.
