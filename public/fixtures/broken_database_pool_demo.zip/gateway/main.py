from fastapi import FastAPI
# ISSUE: Missing /health probe endpoint required for Kubernetes/ECS liveness check
app = FastAPI(title="Gateway Service")

@app.get("/api/catalog")
def get_catalog():
    return [{"item_id": 1, "name": "Standard Plan"}]
