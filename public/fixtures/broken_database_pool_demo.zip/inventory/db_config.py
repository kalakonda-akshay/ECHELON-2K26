import os
# ISSUE: Missing default for POOL_SIZE
MAX_CONNECTIONS = int(os.getenv("MAX_CONNECTIONS"))
DB_URL = "postgresql://user:pass@inventory-db:5432/inventory"
