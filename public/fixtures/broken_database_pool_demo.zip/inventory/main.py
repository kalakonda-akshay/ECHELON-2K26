from fastapi import FastAPI
import psycopg2
from db_config import MAX_CONNECTIONS

app = FastAPI(title="Inventory Service")

@app.get("/health")
def health():
    return {"status": "ok", "max_conn": MAX_CONNECTIONS}
