# E-Commerce Cloud Native Microservices Architecture
Multi-service distributed application with API Gateway (FastAPI), Order Service (Flask + PostgreSQL), and Payment Service (Express + Redis).
