from fastapi import FastAPI, HTTPException
import httpx

app = FastAPI(title="API Gateway", version="1.0.0")

@app.get("/health")
def health_check():
    return {"status": "HEALTHY", "gateway": "online"}

@app.get("/api/v1/catalog")
def get_catalog():
    return {"items": [{"id": 1, "name": "Item A", "price": 29.99}]}

@app.post("/api/v1/checkout")
async def checkout(order_data: dict):
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.post("http://order-service:5000/orders", json=order_data, timeout=5.0)
            return resp.json()
        except httpx.RequestError as exc:
            raise HTTPException(status_code=502, detail=f"Order service upstream error: {str(exc)}")
