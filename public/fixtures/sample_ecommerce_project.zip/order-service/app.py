from flask import Flask, request, jsonify
import requests
import psycopg2

app = Flask(__name__)

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "HEALTHY", "service": "order-service"})

@app.route("/orders", methods=["POST"])
def create_order():
    data = request.get_json() or {}
    # Call payment service downstream
    try:
        pay_res = requests.post("http://payment-service:3000/charge", json={"amount": 29.99}, timeout=4.0)
        return jsonify({"order_id": "ORD-9912", "status": "CONFIRMED", "payment": pay_res.json()}), 201
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Payment failed", "details": str(e)}), 504

@app.route("/orders/<order_id>", methods=["GET"])
def get_order(order_id):
    return jsonify({"order_id": order_id, "status": "COMPLETED"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
