const express = require('express');
const app = express();
app.use(express.json());

app.get('/health', (req, res) => {
  res.json({ status: 'HEALTHY', service: 'payment-service' });
});

app.post('/charge', (req, res) => {
  const { amount } = req.body;
  res.json({ transaction_id: 'tx_' + Date.now(), status: 'SUCCESS', amount });
});

app.get('/transactions/:id', (req, res) => {
  res.json({ id: req.params.id, status: 'SETTLED' });
});

app.listen(3000, () => {
  console.log('Payment service listening on port 3000');
});
