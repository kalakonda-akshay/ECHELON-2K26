import os
from fastapi import FastAPI

app = FastAPI(title="Healthy Store API")
PORT = int(os.getenv("PORT", "8000"))

@app.get("/health")
def health():
    return {"status": "HEALTHY"}

@app.get("/api/items")
def list_items():
    return [{"id": 1, "name": "Item A"}]
